# Проект интеграции трех страниц дрон-системы

## Общий поток интеграции

### 1. Авторизация (decentraton_hack)
- Пользователь регистрируется/авторизуется как пилот
- Система сохраняет данные пилота в базе данных
- После успешной авторизации пользователь получает доступ к странице проверки полета

### 2. Проверка полета (проект)
- Пользователь вводит маршрут полета (координаты)
- Система проверяет маршрут на пересечение с запретными зонами
- Если маршрут одобрен, пользователь получает доступ к странице симуляции
- Если маршрут отклонен, пользователь остается на странице проверки полета

### 3. Симуляция дрона (drone-simulation)
- Система загружает утвержденный маршрут из предыдущего этапа
- Дрон может летать только в пределах утвержденной области
- При попытке выхода за пределы утвержденной области дрон автоматически останавливается

## Механизм передачи данных между страницами

### Передача данных от авторизации к проверке полета
- После успешной авторизации сохраняем ID пилота в localStorage
- Страница проверки полета проверяет наличие ID пилота в localStorage
- Если ID отсутствует, перенаправляем на страницу авторизации

### Передача данных от проверки полета к симуляции
- После одобрения маршрута сохраняем координаты и параметры в localStorage
- Сохраняем статус одобрения (approved: true) в localStorage
- Страница симуляции проверяет статус одобрения в localStorage
- Если статус не "approved", перенаправляем на страницу проверки полета

## Логика проверки одобрения полета

1. После заполнения формы на странице проверки полета:
   - Система анализирует маршрут на пересечение с запретными зонами
   - Проверяет высоту, время и другие параметры полета

2. Результат проверки:
   - Если маршрут одобрен:
     - Устанавливаем флаг `flightApproved = true` в localStorage
     - Сохраняем координаты маршрута в localStorage
     - Активируем кнопку перехода к симуляции
   - Если маршрут отклонен:
     - Устанавливаем флаг `flightApproved = false` в localStorage
     - Отображаем причину отклонения
     - Кнопка перехода к симуляции остается неактивной

3. При загрузке страницы симуляции:
   - Проверяем флаг `flightApproved` в localStorage
   - Если `flightApproved !== true`, перенаправляем на страницу проверки полета

## Механизм контроля области полета дрона

1. Загрузка утвержденного маршрута:
   - При инициализации симуляции загружаем координаты из localStorage
   - Создаем полигон безопасной зоны на основе утвержденного маршрута
   - Добавляем буферную зону вокруг маршрута (например, 100 метров)

2. Контроль во время симуляции:
   - Перед каждым обновлением позиции дрона проверяем, находится ли новая позиция в пределах безопасной зоны
   - Если новая позиция выходит за пределы зоны:
     - Отменяем перемещение
     - Выводим предупреждение о нарушении границ
     - Останавливаем дрон или возвращаем его в безопасную зону

3. Модификация функции `generateNextPosition`:
   - Добавляем проверку новой позиции на соответствие утвержденной зоне
   - Если позиция выходит за пределы зоны, корректируем ее или отменяем перемещение

## Технические детали реализации

### Модификация страницы авторизации
```javascript
// После успешной авторизации
function handleSuccessfulAuth(pilotId) {
  localStorage.setItem('pilotId', pilotId);
  localStorage.setItem('isAuthenticated', 'true');
  window.location.href = '/flight-check.html';
}
```

### Модификация страницы проверки полета
```javascript
// Проверка авторизации при загрузке
window.addEventListener('DOMContentLoaded', () => {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  if (!isAuthenticated) {
    window.location.href = '/auth.html';
    return;
  }
  
  // Остальной код инициализации...
});

// После проверки маршрута
function handleFlightCheck(result) {
  if (result.approved) {
    localStorage.setItem('flightApproved', 'true');
    localStorage.setItem('flightRoute', JSON.stringify(result.route));
    localStorage.setItem('flightParams', JSON.stringify({
      height: result.height,
      time: result.time,
      buffer: result.buffer
    }));
    
    // Активируем кнопку перехода к симуляции
    document.getElementById('goToSimulation').disabled = false;
  } else {
    localStorage.setItem('flightApproved', 'false');
    // Отображаем причину отклонения
    showRejectionReason(result.reason);
  }
}

// Обработчик кнопки перехода к симуляции
document.getElementById('goToSimulation').addEventListener('click', () => {
  window.location.href = '/simulation.html';
});
```

### Модификация страницы симуляции дрона
```javascript
// Проверка одобрения полета при загрузке
window.addEventListener('DOMContentLoaded', () => {
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  const flightApproved = localStorage.getItem('flightApproved') === 'true';
  
  if (!isAuthenticated) {
    window.location.href = '/auth.html';
    return;
  }
  
  if (!flightApproved) {
    window.location.href = '/flight-check.html';
    return;
  }
  
  // Загружаем утвержденный маршрут
  const flightRoute = JSON.parse(localStorage.getItem('flightRoute'));
  const flightParams = JSON.parse(localStorage.getItem('flightParams'));
  
  // Инициализируем симуляцию с утвержденным маршрутом
  initializeSimulation(flightRoute, flightParams);
});

// Модификация функции генерации позиции дрона
function generateNextPosition(current, approvedRoute, safetyBuffer) {
  // Генерируем новую позицию
  const newPosition = { /* ... */ };
  
  // Проверяем, находится ли новая позиция в пределах утвержденной зоны
  if (!isPositionInSafeZone(newPosition, approvedRoute, safetyBuffer)) {
    // Если позиция выходит за пределы зоны, добавляем нарушение
    newPosition.violations.push('Выход за пределы утвержденной зоны полета');
    
    // Останавливаем дрон или корректируем позицию
    newPosition.speed = 0;
    // Возвращаем дрон в безопасную зону
    const correctedPosition = correctPositionToSafeZone(newPosition, approvedRoute);
    return correctedPosition;
  }
  
  return newPosition;
}

// Функция проверки позиции на соответствие утвержденной зоне
function isPositionInSafeZone(position, approvedRoute, safetyBuffer) {
  // Реализация проверки...
}

// Функция коррекции позиции для возврата в безопасную зону
function correctPositionToSafeZone(position, approvedRoute) {
  // Реализация коррекции...
}
```

## Безопасность и валидация

1. Защита от обхода проверок:
   - Все страницы проверяют необходимые флаги в localStorage
   - Серверная валидация для критических операций

2. Защита данных:
   - Чувствительные данные хранятся на сервере
   - В localStorage хранятся только необходимые для работы флаги и параметры

3. Обработка ошибок:
   - Корректная обработка отсутствующих данных
   - Информативные сообщения об ошибках
   - Возможность повторной попытки без потери данных
