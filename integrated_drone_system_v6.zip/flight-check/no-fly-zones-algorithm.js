/**
 * Универсальный алгоритм проверки запретных зон для полётов дронов
 * 
 * Алгоритм учитывает различные типы запретных зон:
 * 1. Аэропорты и аэродромы (круговые зоны)
 * 2. Военные объекты (полигональные зоны)
 * 3. Правительственные здания (круговые или полигональные зоны)
 * 4. Места массового скопления людей (круговые или полигональные зоны)
 * 5. Заповедники и национальные парки (полигональные зоны)
 * 6. Частные территории (полигональные зоны)
 * 7. Центры городов (полигональные или круговые зоны)
 */

/**
 * Типы запретных зон
 */
const ZONE_TYPES = {
  AIRPORT: 'airport',
  MILITARY: 'military',
  GOVERNMENT: 'government',
  CROWDED_PLACE: 'crowded_place',
  NATURE_RESERVE: 'nature_reserve',
  PRIVATE_PROPERTY: 'private_property',
  CITY_CENTER: 'city_center'
};

/**
 * Геометрические типы зон
 */
const GEOMETRY_TYPES = {
  CIRCLE: 'circle',
  POLYGON: 'polygon',
  RECTANGLE: 'rectangle'
};

/**
 * База данных запретных зон
 * Каждая зона содержит:
 * - id: уникальный идентификатор
 * - name: название объекта
 * - type: тип зоны (из ZONE_TYPES)
 * - geometry: тип геометрии (из GEOMETRY_TYPES)
 * - coordinates: координаты в зависимости от типа геометрии
 *   - для CIRCLE: {center: {lat, lng}, radius: метры}
 *   - для POLYGON: массив точек [{lat, lng}, ...]
 *   - для RECTANGLE: {minLat, minLng, maxLat, maxLng}
 * - buffer: дополнительный буфер безопасности в метрах
 * - restrictions: особые ограничения (высота, время и т.д.)
 */
const noFlyZones = [
  // Аэропорты
  {
    id: 'airport-1',
    name: 'Международный аэропорт Нурсултан Назарбаев',
    type: ZONE_TYPES.AIRPORT,
    geometry: GEOMETRY_TYPES.CIRCLE,
    coordinates: {
      center: { lat: 51.0222, lng: 71.4669 },
      radius: 8000 // 8 км
    },
    buffer: 1000, // дополнительный буфер 1 км
    restrictions: {
      maxHeight: 0, // полный запрет полётов
      timeRestrictions: null // ограничения по времени отсутствуют
    },
    color: '#ef4444' // красный
  },
  
  // Правительственные здания
  {
    id: 'gov-1',
    name: 'Ак Орда (резиденция президента)',
    type: ZONE_TYPES.GOVERNMENT,
    geometry: GEOMETRY_TYPES.CIRCLE,
    coordinates: {
      center: { lat: 51.1271, lng: 71.4300 },
      radius: 1000 // 1 км
    },
    buffer: 500, // дополнительный буфер 500 м
    restrictions: {
      maxHeight: 0, // полный запрет полётов
      timeRestrictions: null // ограничения по времени отсутствуют
    },
    color: '#7e22ce' // фиолетовый
  },
  
  // Военные объекты (пример)
  {
    id: 'mil-1',
    name: 'Военная часть',
    type: ZONE_TYPES.MILITARY,
    geometry: GEOMETRY_TYPES.POLYGON,
    coordinates: [
      { lat: 51.1500, lng: 71.4800 },
      { lat: 51.1550, lng: 71.4900 },
      { lat: 51.1600, lng: 71.4850 },
      { lat: 51.1550, lng: 71.4750 }
    ],
    buffer: 2000, // дополнительный буфер 2 км
    restrictions: {
      maxHeight: 0, // полный запрет полётов
      timeRestrictions: null // ограничения по времени отсутствуют
    },
    color: '#b91c1c' // темно-красный
  },
  
  // Места массового скопления людей (пример)
  {
    id: 'crowd-1',
    name: 'Стадион Астана Арена',
    type: ZONE_TYPES.CROWDED_PLACE,
    geometry: GEOMETRY_TYPES.CIRCLE,
    coordinates: {
      center: { lat: 51.1089, lng: 71.4026 },
      radius: 500 // 500 м
    },
    buffer: 300, // дополнительный буфер 300 м
    restrictions: {
      maxHeight: 0, // полный запрет полётов
      timeRestrictions: {
        // Ограничения во время мероприятий
        events: [
          {
            start: '2025-05-25T14:00:00',
            end: '2025-05-25T18:00:00',
            description: 'Футбольный матч'
          }
        ]
      }
    },
    color: '#f59e0b' // оранжевый
  },
  
  // Заповедники (пример)
  {
    id: 'nature-1',
    name: 'Коргалжынский заповедник',
    type: ZONE_TYPES.NATURE_RESERVE,
    geometry: GEOMETRY_TYPES.RECTANGLE,
    coordinates: {
      minLat: 50.4500,
      minLng: 69.5000,
      maxLat: 50.6500,
      maxLng: 70.0000
    },
    buffer: 1000, // дополнительный буфер 1 км
    restrictions: {
      maxHeight: 300, // ограничение высоты 300 м
      timeRestrictions: null // ограничения по времени отсутствуют
    },
    color: '#15803d' // зеленый
  },
  
  // Центр города (пример)
  {
    id: 'city-1',
    name: 'Центр Астаны',
    type: ZONE_TYPES.CITY_CENTER,
    geometry: GEOMETRY_TYPES.CIRCLE,
    coordinates: {
      center: { lat: 51.1282, lng: 71.4306 },
      radius: 3000 // 3 км
    },
    buffer: 0, // без дополнительного буфера
    restrictions: {
      maxHeight: 50, // ограничение высоты 50 м
      timeRestrictions: null // ограничения по времени отсутствуют
    },
    color: '#1d4ed8' // синий
  }
];

/**
 * Проверяет, находится ли точка внутри круга
 * @param {Object} point - Точка {lat, lng}
 * @param {Object} circle - Круг {center: {lat, lng}, radius: метры}
 * @return {boolean} - true, если точка внутри круга
 */
function isPointInCircle(point, circle) {
  const distance = calculateDistance(
    point.lat, point.lng,
    circle.center.lat, circle.center.lng
  );
  return distance <= circle.radius;
}

/**
 * Проверяет, находится ли точка внутри прямоугольника
 * @param {Object} point - Точка {lat, lng}
 * @param {Object} rect - Прямоугольник {minLat, minLng, maxLat, maxLng}
 * @return {boolean} - true, если точка внутри прямоугольника
 */
function isPointInRectangle(point, rect) {
  return (
    point.lat >= rect.minLat &&
    point.lat <= rect.maxLat &&
    point.lng >= rect.minLng &&
    point.lng <= rect.maxLng
  );
}

/**
 * Проверяет, находится ли точка внутри полигона (алгоритм ray casting)
 * @param {Object} point - Точка {lat, lng}
 * @param {Array} polygon - Массив точек [{lat, lng}, ...]
 * @return {boolean} - true, если точка внутри полигона
 */
function isPointInPolygon(point, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].lng;
    const yi = polygon[i].lat;
    const xj = polygon[j].lng;
    const yj = polygon[j].lat;
    
    const intersect = ((yi > point.lat) !== (yj > point.lat)) &&
      (point.lng < (xj - xi) * (point.lat - yi) / (yj - yi) + xi);
    
    if (intersect) inside = !inside;
  }
  
  return inside;
}

/**
 * Проверяет, пересекает ли линия круг
 * @param {Object} start - Начальная точка {lat, lng}
 * @param {Object} end - Конечная точка {lat, lng}
 * @param {Object} circle - Круг {center: {lat, lng}, radius: метры}
 * @return {boolean} - true, если линия пересекает круг
 */
function doesLineIntersectCircle(start, end, circle) {
  // Проверяем, находятся ли точки внутри круга
  if (isPointInCircle(start, circle) || isPointInCircle(end, circle)) {
    return true;
  }
  
  // Находим ближайшую точку на линии к центру круга
  const dx = end.lng - start.lng;
  const dy = end.lat - start.lat;
  
  // Если линия - точка, уже проверили выше
  if (dx === 0 && dy === 0) {
    return false;
  }
  
  // Параметр t для ближайшей точки на линии
  const t = ((circle.center.lng - start.lng) * dx + (circle.center.lat - start.lat) * dy) / 
            (dx * dx + dy * dy);
  
  let closestPoint;
  if (t < 0) {
    closestPoint = start;
  } else if (t > 1) {
    closestPoint = end;
  } else {
    closestPoint = {
      lng: start.lng + t * dx,
      lat: start.lat + t * dy
    };
  }
  
  // Проверяем, находится ли ближайшая точка внутри круга
  return isPointInCircle(closestPoint, circle);
}

/**
 * Проверяет, пересекает ли линия прямоугольник
 * @param {Object} start - Начальная точка {lat, lng}
 * @param {Object} end - Конечная точка {lat, lng}
 * @param {Object} rect - Прямоугольник {minLat, minLng, maxLat, maxLng}
 * @return {boolean} - true, если линия пересекает прямоугольник
 */
function doesLineIntersectRectangle(start, end, rect) {
  // Проверяем, находятся ли точки внутри прямоугольника
  if (isPointInRectangle(start, rect) || isPointInRectangle(end, rect)) {
    return true;
  }
  
  // Проверяем пересечение с каждой из сторон прямоугольника
  const rectLines = [
    // Нижняя сторона
    { start: {lat: rect.minLat, lng: rect.minLng}, end: {lat: rect.minLat, lng: rect.maxLng} },
    // Правая сторона
    { start: {lat: rect.minLat, lng: rect.maxLng}, end: {lat: rect.maxLat, lng: rect.maxLng} },
    // Верхняя сторона
    { start: {lat: rect.maxLat, lng: rect.maxLng}, end: {lat: rect.maxLat, lng: rect.minLng} },
    // Левая сторона
    { start: {lat: rect.maxLat, lng: rect.minLng}, end: {lat: rect.minLat, lng: rect.minLng} }
  ];
  
  for (const line of rectLines) {
    if (doLinesIntersect(start, end, line.start, line.end)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Проверяет, пересекает ли линия полигон
 * @param {Object} start - Начальная точка {lat, lng}
 * @param {Object} end - Конечная точка {lat, lng}
 * @param {Array} polygon - Массив точек [{lat, lng}, ...]
 * @return {boolean} - true, если линия пересекает полигон
 */
function doesLineIntersectPolygon(start, end, polygon) {
  // Проверяем, находятся ли точки внутри полигона
  if (isPointInPolygon(start, polygon) || isPointInPolygon(end, polygon)) {
    return true;
  }
  
  // Проверяем пересечение с каждой из сторон полигона
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const lineStart = polygon[j];
    const lineEnd = polygon[i];
    
    if (doLinesIntersect(start, end, lineStart, lineEnd)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Проверяет, пересекаются ли две линии
 * @param {Object} p1 - Начальная точка первой линии {lat, lng}
 * @param {Object} p2 - Конечная точка первой линии {lat, lng}
 * @param {Object} p3 - Начальная точка второй линии {lat, lng}
 * @param {Object} p4 - Конечная точка второй линии {lat, lng}
 * @return {boolean} - true, если линии пересекаются
 */
function doLinesIntersect(p1, p2, p3, p4) {
  // Вычисляем определители
  const d1 = (p4.lat - p3.lat) * (p2.lng - p1.lng) - (p4.lng - p3.lng) * (p2.lat - p1.lat);
  
  // Если линии параллельны
  if (d1 === 0) return false;
  
  const ua = ((p4.lng - p3.lng) * (p1.lat - p3.lat) - (p4.lat - p3.lat) * (p1.lng - p3.lng)) / d1;
  const ub = ((p2.lng - p1.lng) * (p1.lat - p3.lat) - (p2.lat - p1.lat) * (p1.lng - p3.lng)) / d1;
  
  // Если пересечение находится на обеих линиях
  return ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1;
}

/**
 * Рассчитывает расстояние между двумя точками в метрах (формула гаверсинусов)
 * @param {number} lat1 - Широта первой точки
 * @param {number} lng1 - Долгота первой точки
 * @param {number} lat2 - Широта второй точки
 * @param {number} lng2 - Долгота второй точки
 * @return {number} - Расстояние в метрах
 */
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371000; // радиус Земли в метрах
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lng2 - lng1) * Math.PI / 180;
  
  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
           Math.cos(φ1) * Math.cos(φ2) *
           Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  
  return R * c;
}

/**
 * Расширяет зону с учетом буфера
 * @param {Object} zone - Запретная зона
 * @param {number} customBuffer - Пользовательский буфер (если указан)
 * @return {Object} - Расширенная зона с учетом буфера
 */
function expandZoneWithBuffer(zone, customBuffer) {
  const expandedZone = { ...zone };
  const buffer = customBuffer !== undefined ? customBuffer : zone.buffer;
  
  if (buffer <= 0) {
    return expandedZone;
  }
  
  // Коэффициент для преобразования метров в градусы (примерно)
  // 1 градус широты = 111 км, 1 градус долготы = 111 * cos(широта) км
  let lat;
  switch (zone.geometry) {
    case GEOMETRY_TYPES.CIRCLE:
      expandedZone.coordinates = {
        center: { ...zone.coordinates.center },
        radius: zone.coordinates.radius + buffer
      };
      break;
      
    case GEOMETRY_TYPES.RECTANGLE:
      lat = (zone.coordinates.minLat + zone.coordinates.maxLat) / 2;
      const latDegreePerMeter = 1 / 111000;
      const lngDegreePerMeter = 1 / (111000 * Math.cos(lat * Math.PI / 180));
      
      const latBuffer = buffer * latDegreePerMeter;
      const lngBuffer = buffer * lngDegreePerMeter;
      
      expandedZone.coordinates = {
        minLat: zone.coordinates.minLat - latBuffer,
        minLng: zone.coordinates.minLng - lngBuffer,
        maxLat: zone.coordinates.maxLat + latBuffer,
        maxLng: zone.coordinates.maxLng + lngBuffer
      };
      break;
      
    case GEOMETRY_TYPES.POLYGON:
      // Для полигонов буфер реализуется при визуализации
      // Здесь можно было бы использовать алгоритм расширения полигона,
      // но это сложнее и требует дополнительных библиотек
      break;
  }
  
  return expandedZone;
}

/**
 * Проверяет, пересекает ли точка запретную зону
 * @param {Object} point - Точка {lat, lng}
 * @param {Object} zone - Запретная зона
 * @return {Object} - Результат проверки {intersects, reason}
 */
function checkPointInZone(point, zone) {
  let intersects = false;
  
  switch (zone.geometry) {
    case GEOMETRY_TYPES.CIRCLE:
      intersects = isPointInCircle(point, zone.coordinates);
      break;
      
    case GEOMETRY_TYPES.RECTANGLE:
      intersects = isPointInRectangle(point, zone.coordinates);
      break;
      
    case GEOMETRY_TYPES.POLYGON:
      intersects = isPointInPolygon(point, zone.coordinates);
      break;
  }
  
  if (intersects) {
    return {
      intersects: true,
      reason: `Точка маршрута находится в запретной зоне "${zone.name}"`
    };
  }
  
  return { intersects: false };
}

/**
 * Проверяет, пересекает ли линия запретную зону
 * @param {Object} start - Начальная точка {lat, lng}
 * @param {Object} end - Конечная точка {lat, lng}
 * @param {Object} zone - Запретная зона
 * @return {Object} - Результат проверки {intersects, reason}
 */
function checkLineInZone(start, end, zone) {
  let intersects = false;
  
  switch (zone.geometry) {
    case GEOMETRY_TYPES.CIRCLE:
      intersects = doesLineIntersectCircle(start, end, zone.coordinates);
      break;
      
    case GEOMETRY_TYPES.RECTANGLE:
      intersects = doesLineIntersectRectangle(start, end, zone.coordinates);
      break;
      
    case GEOMETRY_TYPES.POLYGON:
      intersects = doesLineIntersectPolygon(start, end, zone.coordinates);
      break;
  }
  
  if (intersects) {
    return {
      intersects: true,
      reason: `Линия маршрута пересекает запретную зону "${zone.name}"`
    };
  }
  
  return { intersects: false };
}

/**
 * Проверяет, соответствует ли высота полета ограничениям зоны
 * @param {number} flightHeight - Высота полета в метрах
 * @param {Object} zone - Запретная зона
 * @param {boolean} isInZone - Находится ли маршрут в зоне
 * @return {Object} - Результат проверки {valid, reason}
 */
function checkHeightRestrictions(flightHeight, zone, isInZone) {
  // Если маршрут не находится в зоне, ограничения не применяются
  if (!isInZone) {
    return { valid: true };
  }
  
  if (zone.restrictions && zone.restrictions.maxHeight !== null) {
    if (zone.restrictions.maxHeight === 0) {
      return {
        valid: false,
        reason: `Полеты в зоне "${zone.name}" полностью запрещены`
      };
    } else if (flightHeight > zone.restrictions.maxHeight) {
      return {
        valid: false,
        reason: `Высота полета (${flightHeight}м) превышает максимально допустимую (${zone.restrictions.maxHeight}м) в зоне "${zone.name}"`
      };
    }
  }
  
  return { valid: true };
}

/**
 * Проверяет, соответствует ли время полета ограничениям зоны
 * @param {Date} flightTime - Время полета
 * @param {Object} zone - Запретная зона
 * @param {boolean} isInZone - Находится ли маршрут в зоне
 * @return {Object} - Результат проверки {valid, reason}
 */
function checkTimeRestrictions(flightTime, zone, isInZone) {
  // Если маршрут не находится в зоне, ограничения не применяются
  if (!isInZone) {
    return { valid: true };
  }
  
  if (zone.restrictions && zone.restrictions.timeRestrictions && 
      zone.restrictions.timeRestrictions.events) {
    
    for (const event of zone.restrictions.timeRestrictions.events) {
      const eventStart = new Date(event.start);
      const eventEnd = new Date(event.end);
      
      if (flightTime >= eventStart && flightTime <= eventEnd) {
        return {
          valid: false,
          reason: `Полет в зоне "${zone.name}" запрещен во время мероприятия "${event.description}" (${eventStart.toLocaleString()} - ${eventEnd.toLocaleString()})`
        };
      }
    }
  }
  
  return { valid: true };
}

/**
 * Проверяет, находится ли маршрут слишком далеко от запретных зон
 * @param {Array} coordinates - Массив координат маршрута
 * @param {Object} zone - Запретная зона
 * @return {boolean} - true, если маршрут находится слишком далеко от зоны
 */
function isRouteTooFarFromZone(coordinates, zone) {
  // Определяем центр зоны
  let zoneCenter;
  let zoneRadius = 0;
  
  switch (zone.geometry) {
    case GEOMETRY_TYPES.CIRCLE:
      zoneCenter = zone.coordinates.center;
      zoneRadius = zone.coordinates.radius + zone.buffer;
      break;
      
    case GEOMETRY_TYPES.RECTANGLE:
      zoneCenter = {
        lat: (zone.coordinates.minLat + zone.coordinates.maxLat) / 2,
        lng: (zone.coordinates.minLng + zone.coordinates.maxLng) / 2
      };
      // Приблизительный радиус прямоугольника (половина диагонали)
      const width = calculateDistance(
        zone.coordinates.minLat, zone.coordinates.minLng,
        zone.coordinates.minLat, zone.coordinates.maxLng
      );
      const height = calculateDistance(
        zone.coordinates.minLat, zone.coordinates.minLng,
        zone.coordinates.maxLat, zone.coordinates.minLng
      );
      zoneRadius = Math.sqrt(width * width + height * height) / 2 + zone.buffer;
      break;
      
    case GEOMETRY_TYPES.POLYGON:
      // Для полигона вычисляем центроид
      let sumLat = 0;
      let sumLng = 0;
      for (const point of zone.coordinates) {
        sumLat += point.lat;
        sumLng += point.lng;
      }
      zoneCenter = {
        lat: sumLat / zone.coordinates.length,
        lng: sumLng / zone.coordinates.length
      };
      
      // Находим максимальное расстояние от центроида до вершин полигона
      let maxDistance = 0;
      for (const point of zone.coordinates) {
        const distance = calculateDistance(
          zoneCenter.lat, zoneCenter.lng,
          point.lat, point.lng
        );
        maxDistance = Math.max(maxDistance, distance);
      }
      zoneRadius = maxDistance + zone.buffer;
      break;
  }
  
  // Проверяем минимальное расстояние от любой точки маршрута до центра зоны
  const maxCheckDistance = 100000; // 100 км - максимальное расстояние для проверки
  let minDistance = Number.MAX_VALUE;
  
  // Проверяем каждую точку маршрута
  for (const point of coordinates) {
    const distance = calculateDistance(
      point.lat, point.lng,
      zoneCenter.lat, zoneCenter.lng
    );
    minDistance = Math.min(minDistance, distance);
  }
  
  // Если минимальное расстояние больше максимального расстояния проверки + радиус зоны,
  // считаем, что маршрут слишком далеко от зоны
  return minDistance > (maxCheckDistance + zoneRadius);
}

/**
 * Проверяет маршрут на пересечение с запретными зонами
 * @param {Array} coordinates - Массив координат маршрута
 * @param {number} flightHeight - Высота полета в метрах
 * @param {number} flightTime - Время полета в минутах
 * @param {string} flightDate - Дата и время полета в формате ISO
 * @param {number} bufferDistance - Буферное расстояние в метрах
 * @return {Object} - Результат проверки {approved, reason, route, height, time, date, buffer}
 */
function checkRoute(coordinates, flightHeight, flightTime, flightDate, bufferDistance) {
  // Проверяем каждую точку маршрута
  for (const point of coordinates) {
    for (const zone of noFlyZones) {
      // Проверяем, находится ли маршрут слишком далеко от зоны
      if (isRouteTooFarFromZone(coordinates, zone)) {
        continue; // Пропускаем проверку для этой зоны
      }
      
      // Расширяем зону с учетом буфера
      const expandedZone = expandZoneWithBuffer(zone, bufferDistance);
      
      // Проверяем точку
      const pointCheck = checkPointInZone(point, expandedZone);
      if (pointCheck.intersects) {
        // Проверяем высоту только если точка находится в зоне
        if (expandedZone.restrictions) {
          const heightCheck = checkHeightRestrictions(flightHeight, expandedZone, true);
          if (!heightCheck.valid) {
            return {
              approved: false,
              reason: heightCheck.reason
            };
          }
        }
        
        return {
          approved: false,
          reason: pointCheck.reason
        };
      }
    }
  }
  
  // Проверяем каждый сегмент маршрута
  for (let i = 0; i < coordinates.length - 1; i++) {
    const start = coordinates[i];
    const end = coordinates[i + 1];
    
    for (const zone of noFlyZones) {
      // Проверяем, находится ли маршрут слишком далеко от зоны
      if (isRouteTooFarFromZone(coordinates, zone)) {
        continue; // Пропускаем проверку для этой зоны
      }
      
      // Расширяем зону с учетом буфера
      const expandedZone = expandZoneWithBuffer(zone, bufferDistance);
      
      // Проверяем линию
      const lineCheck = checkLineInZone(start, end, expandedZone);
      if (lineCheck.intersects) {
        // Проверяем высоту только если линия пересекает зону
        if (expandedZone.restrictions) {
          const heightCheck = checkHeightRestrictions(flightHeight, expandedZone, true);
          if (!heightCheck.valid) {
            return {
              approved: false,
              reason: heightCheck.reason
            };
          }
        }
        
        return {
          approved: false,
          reason: lineCheck.reason
        };
      }
    }
  }
  
  // Если все проверки пройдены, маршрут одобрен
  return {
    approved: true,
    route: coordinates,
    height: flightHeight,
    time: flightTime,
    date: flightDate,
    buffer: bufferDistance
  };
}
